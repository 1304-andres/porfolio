/**
 * Portfolio data — edit this file to update content without touching HTML.
 *
 * @typedef {Object} Project
 * @property {string} id
 * @property {string} name
 * @property {string} description
 * @property {string[]} stack
 * @property {string} repo       - GitHub repo URL
 * @property {string} demo       - Live demo URL
 * @property {string} year
 * @property {string} [accent]   - Optional hex accent for card glyph
 *
 * @typedef {Object} Skill
 * @property {string} name
 * @property {number} level      - 0..100
 *
 * @typedef {Object} SkillGroup
 * @property {string} category
 * @property {Skill[]} items
 */

/** @type {Project[]} */
const PROJECTS = [
  {
    id: "p01",
    name: "E-commerce Dashboard",
    description:
      "Real-time analytics console for a mid-market retailer. 40+ chart widgets, drag-to-arrange layout, CSV export, role-based views.",
    stack: ["Angular 17", "RxJS", "NgRx", "D3", "Tailwind"],
    repo: "https://github.com/username/ecom-dashboard",
    demo: "https://ecom-dash.demo.dev",
    year: "2025",
    accent: "#00D4FF",
  },
  {
    id: "p02",
    name: "Flightdeck",
    description:
      "Operations tool for a regional airline — gate assignments, crew rotations, live METAR overlays. Offline-first with IndexedDB sync.",
    stack: ["Angular 16", "TypeScript", "RxJS", "Leaflet", "Workbox"],
    repo: "https://github.com/username/flightdeck",
    demo: "https://flightdeck.demo.dev",
    year: "2024",
    accent: "#7C5CFF",
  },
  {
    id: "p03",
    name: "Lumen CMS",
    description:
      "Headless content editor with block-based composition, version diffing, and a plugin API. Ships with a WYSIWYG preview iframe.",
    stack: ["Angular", "Signals", "Vite", "Zod", "Storybook"],
    repo: "https://github.com/username/lumen-cms",
    demo: "https://lumen.demo.dev",
    year: "2024",
    accent: "#30E0A1",
  },
  {
    id: "p04",
    name: "Ledgerline",
    description:
      "Double-entry bookkeeping UI for small businesses. Keyboard-driven, auto-reconciliation, locale-aware formatting for 14 currencies.",
    stack: ["Angular", "RxJS", "IndexedDB", "CSS Grid"],
    repo: "https://github.com/username/ledgerline",
    demo: "https://ledgerline.demo.dev",
    year: "2023",
    accent: "#FFB84D",
  },
  {
    id: "p05",
    name: "Northbeam Design System",
    description:
      "Component library of 62 primitives with a live tokens playground. Themeable via CSS variables; tree-shakeable per-component.",
    stack: ["Angular CDK", "SCSS", "Rollup", "a11y"],
    repo: "https://github.com/username/northbeam-ds",
    demo: "https://northbeam.demo.dev",
    year: "2023",
    accent: "#FF6B9D",
  },
  {
    id: "p06",
    name: "Tessera",
    description:
      "A tile-based data explorer for geospatial datasets. WebGL rendering, custom zoom tiles, saved views, and shareable URLs.",
    stack: ["TypeScript", "WebGL", "MapLibre", "Web Workers"],
    repo: "https://github.com/username/tessera",
    demo: "https://tessera.demo.dev",
    year: "2022",
    accent: "#00D4FF",
  },
];

/** @type {SkillGroup[]} */
const SKILL_GROUPS = [
  {
    category: "Frameworks",
    items: [
      { name: "Angular", level: 95 },
      { name: "RxJS", level: 92 },
      { name: "NgRx", level: 85 },
      { name: "React", level: 78 },
      { name: "Svelte", level: 65 },
    ],
  },
  {
    category: "Languages",
    items: [
      { name: "TypeScript", level: 94 },
      { name: "JavaScript", level: 96 },
      { name: "HTML5", level: 95 },
      { name: "CSS / SCSS", level: 93 },
      { name: "Node.js", level: 80 },
    ],
  },
  {
    category: "Tools & Craft",
    items: [
      { name: "Vite / Webpack", level: 88 },
      { name: "Storybook", level: 86 },
      { name: "Jest / Vitest", level: 84 },
      { name: "Figma", level: 82 },
      { name: "Git / CI", level: 90 },
    ],
  },
];

/** Case study — featured project deep-dive. */
const CASE_STUDY = {
  project: "Flightdeck",
  tagline: "Rebuilding a 20-year-old dispatch tool for a regional airline.",
  problem:
    "Dispatchers ran a 2005-era Java applet that crashed 6–8 times a shift and couldn't load on tablets. Every outage grounded planning until someone restarted it. Training a new dispatcher took 11 weeks — most of that was muscle memory for a UI no one had ever redesigned.",
  solution:
    "An Angular PWA with an offline-first architecture: all gate and crew state is written to IndexedDB first, then synced to the API when the tablet has signal. The UI is one continuous timeline view per runway, so dispatchers can see 8 hours of ops at a glance and drag-rearrange crew rotations in place.",
  decisions: [
    { label: "Angular + Signals", reason: "Incremental adoption path from the AngularJS app two other teams still owned." },
    { label: "IndexedDB via Dexie", reason: "Dispatchers work on tablets in hangars with flaky wifi. Writes must never block UI." },
    { label: "CSS Grid timeline", reason: "A canvas renderer was faster but unreadable for screen-reader users and ops trainers." },
    { label: "No state-management library", reason: "Signals + services covered it. Every kilobyte matters on trainee tablets." },
  ],
  results: [
    { metric: "11 → 3 wks", label: "Onboarding time for new dispatchers" },
    { metric: "6–8 → 0", label: "Daily crashes, first quarter post-launch" },
    { metric: "320 ms", label: "Median interaction latency, 95th percentile" },
    { metric: "A11y AA", label: "Full WCAG 2.1 AA conformance, audited" },
  ],
};

/** Personal — about, socials. */
const PROFILE = {
  name: "Alex Rivera",
  role: "Frontend Developer · Angular Specialist",
  location: "Barcelona, ES",
  years: 7,
  bio:
    "I build front-ends for operational software — the kind people use 8 hours a day and rely on to not break. Most of that work is in Angular, but the interesting part is always the same: how do you keep the interface fast, honest, and maintainable as the business gets more complicated? I like problems where the UX and the architecture are the same problem.",
  differentiators: [
    {
      title: "Operator-grade UX",
      body: "I design for the person who'll use it for 2,000 hours, not the person demoing it for 2 minutes.",
    },
    {
      title: "Architecture that ages",
      body: "Signals, clear boundaries, tests that document behavior. Code that new teammates can read on day one.",
    },
    {
      title: "Performance as a feature",
      body: "Budgets, Lighthouse in CI, real-user metrics. If it isn't measured, it will regress.",
    },
  ],
  social: {
    github: "https://github.com/username",
    linkedin: "https://linkedin.com/in/username",
    email: "alex@rivera.dev",
  },
};

// Expose globals for script.js (no modules — GitHub Pages friendly).
window.PORTFOLIO_DATA = { PROJECTS, SKILL_GROUPS, CASE_STUDY, PROFILE };
